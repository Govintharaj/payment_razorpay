step 1: Within this payment folder create a virtual env with python3.
step 2: Activate an environment.
step 3: Install the depentency package using "pip3 install -r requirements.txt"
step 4: Navigate to the payment folder and import the database backup
or using makemigrations followed by migrate command create a DB with name "payment" with your user account
step 5: start a django Project by run the server. 
