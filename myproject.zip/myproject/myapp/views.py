from django.shortcuts import render
from django.http import HttpResponse
from django.contrib import messages
import razorpay


#Configure Razorpay Thirdparty Payment. 

client = razorpay.Client(auth=("rzp_test_5iqD9AyAWmz7MB", "rweHiWjIoxqY9S8UJzotVvze"))
client.set_app_details({"title" : "Django", "version" : "3.0.7"})

# Create your views here.

def index(request):
    return render(request, "payment.html",  {})

def pay(request):
    data = {}
    if request.method =='POST':

        data['amount'] = request.POST.get('amt')
        data['currency'] = request.POST.get('cur') 
        data['receipt'] = request.POST.get('rec')
        payment = client.order.create(data = data)
        data['name'] = request.POST.get('username')
        data['eamil'] = request.POST.get('email')
        data['contact'] = request.POST.get('con')
        data['description'] = request.POST.get('dec')
        data.update(payment)
        print(data)
    return render(request, "order.html",  {"order" : data})

